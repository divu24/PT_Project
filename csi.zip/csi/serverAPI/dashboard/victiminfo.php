<?php
    $val=$_POST['selected'];
    if($val==0)
    {
        echo "";
    }
    else
    {
        include "../db.php";
        $sql="select * from main where uid=".$val."";
        $result=mysqli_query($con,$sql);
        if($result)
        {
            $row=mysqli_fetch_array($result); 
            echo "<br><br><div>\n";
            echo "<b style=\"font-size: 26;\">".$row['username']."@".$row['hostname']."</b><br>";
            echo "Tracking Since: ".$row['timestamp']."<br>";
            echo "Operating System Type: ".$row['os']."<br>";
            echo "Public IP: ".$row['public_ip']."<br>";
            echo "Private IP: ".$row['private_ip']."";
            echo "</div>\n";
        }
        echo "<br><div>\n";
        
        // For CPU Usage
        $sql="select * from data where uid=".$val." and parameter='cpu' order by timestamp desc";
        $result=mysqli_query($con,$sql);
        if($result)
        {
            if(mysqli_num_rows($result) > 0)
            {
                $row=mysqli_fetch_array($result); 
                echo "CPU Usage: ".$row['value']."% [<i><b>Last Refreshed</b>: ".$row['timestamp']."]</i><br>";
            }
            else
            {
                echo "CPU Usage: null<br>";
            }
        }
        
        // For RAM Usage
        $sql="select * from data where uid=".$val." and parameter='ram' order by timestamp desc";
        $result=mysqli_query($con,$sql);
        if($result)
        {
            if(mysqli_num_rows($result) > 0)
            {
                $row=mysqli_fetch_array($result); 
                echo "RAM Usage: ".$row['value']."% [<i><b>Last Refreshed</b>: ".$row['timestamp']."]</i><br>";
            }
            else
            {
                echo "RAM Usage: null<br>";
            }
        }
        
        // For Battery Level
        $sql="select * from data where uid=".$val." and parameter='battery' order by timestamp desc";
        $result=mysqli_query($con,$sql);
        if($result)
        {
            if(mysqli_num_rows($result) > 0)
            {
                $row=mysqli_fetch_array($result); 
                echo "Battery Level: ".$row['value']."% [<i><b>Last Refreshed</b>: ".$row['timestamp']."]</i><br>";
            }
            else
            {
                echo "Battery Level: null<br>";
            }
        }
        
        // For Power Source
        $sql="select * from data where uid=".$val." and parameter='power_source' order by timestamp desc";
        $result=mysqli_query($con,$sql);
        if($result)
        {
            if(mysqli_num_rows($result) > 0)
            {
                $row=mysqli_fetch_array($result); 
                echo "Power Source: ".$row['value']." [<i><b>Last Refreshed</b>: ".$row['timestamp']."]</i><br>";
            }
            else
            {
                echo "Power Source: null<br>";
            }
        }
        
        // For System uptime
        $sql="select * from data where uid=".$val." and parameter='uptime' order by timestamp desc";
        $result=mysqli_query($con,$sql);
        if($result)
        {
            if(mysqli_num_rows($result) > 0)
            {
                $row=mysqli_fetch_array($result); 
                echo "Uptime: ".$row['value']." hrs [<i><b>Last Refreshed</b>: ".$row['timestamp']."]</i><br>";
            }
            else
            {
                echo "Uptime: null<br>";
            }
        }
        
        
        
        
        echo "</div>\n";
    }
?>