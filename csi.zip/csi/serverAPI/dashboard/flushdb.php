<?php
    include "../db.php";
    $sql="truncate main";
    $result=mysqli_query($con,$sql);
    
    $sql1="truncate data";
    $result1=mysqli_query($con,$sql1);
    
    if($result && $result1)
    {
        header('Location: ./');   
    }
?>