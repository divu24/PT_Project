<html>
<head>
<title>Dashboard | Computer Security Intrusion | Programming Tools Project</title>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script>
window.onload = function () {

var chart = new CanvasJS.Chart("chartContainer", {
	title: {
		text: "Average CPU & RAM Statistics for all the machines for the last few seconds"
	},
	axisX: {
		title: "Time",
		suffix: " sec"
		//valueFormatString: "Time"
		
	},
	axisY2: {
		title: "Percentage",
		//prefix: "$",
		suffix: "%"
	},
	toolTip: {
		shared: true
	},
	legend: {
		cursor: "pointer",
		verticalAlign: "top",
		horizontalAlign: "center",
		dockInsidePlotArea: true,
		itemclick: toogleDataSeries
	},
	data: [{
		type:"line",
		axisYType: "secondary",
		name: "CPU",
		showInLegend: true,
		markerSize: 0,
		yValueFormatString: "##%",
		dataPoints: [
<?php
    include "../db.php";
    
    $sql="select * from data where parameter='cpu' order by timestamp desc limit 0,8";
    $result=mysqli_query($con,$sql);
    if($result)
    {
        $count=0;
        while($row=mysqli_fetch_array($result))
        {
            if($count >= 7)
                break;
            echo "{ x: ".$count.", y: ".($row['value']/100)."},\n";
            $count++;
        }
    }

?>
		]
	},
	{
		type: "line",
		axisYType: "secondary",
		name: "RAM",
		showInLegend: true,
		markerSize: 0,
		yValueFormatString: "##%",
		dataPoints: [
<?php
    $sql="select * from data where parameter='ram' order by timestamp desc limit 0,8";
    $result=mysqli_query($con,$sql);
    if($result)
    {
        $count=0;
        while($row=mysqli_fetch_array($result))
        {
            if($count >= 7)
                break;
            echo "{ x: ".$count.", y: ".($row['value']/100)."},\n";
            $count++;
        }
    }
    mysqli_close($con);

?>
		]
	},
	
]
});
chart.render();

function toogleDataSeries(e){
	if (typeof(e.dataSeries.visible) === "undefined" || e.dataSeries.visible) {
		e.dataSeries.visible = false;
	} else{
		e.dataSeries.visible = true;
	}
	chart.render();
}

}
</script>
<script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
</head>
<body>
<script>
    var timerR=null;
    $(document).ready(function(){
        refreshVictims();
        var height = Math.max($("#details").height(), $("#chartContainer").height());
        $("#details").height(height);
        $("#chartContainer").height(height);
    });

    function refreshVictims(){
        $('#details').html("");
        $('#selectbtn').val('0');
        clearTimeout(timerR);
        $('#selectbtndiv').load('selectbtn.php');
    }
    
    $(function(){
        $('#refresh').click(function() {
            refreshVictims();
        });
    });
    
    function refreshData(){
        $.post('victiminfo.php', { selected: $('#selectbtn').val() },
            function(data) {
                $('#details').html(data);
            }
        );
        timerR = setTimeout(refreshData, 5000);
    }
    
    $(document.body).on('change','#selectbtn',function(){
        $('#details').html("<p><b>Loading...</b></p>");
        refreshData();
    });
    
    function confirm() {
        alert('Are you sure you want to flush the complete database ? This cannot be undone.');
    }
</script>
<h1>Computer Security Intrusion - Dashboard</h1>
<p>This is the Programming Tools Project for the session 2017-18. The group members are:-<br>1. Divya Chadha<br>2. Gaurav Tibrewal<br>3. Harshit Budhraja</p>
<h3 style="color: red">ADMIN CONTROLS (Handle with care)</h3>
<form method="post" action="flushdb.php" onSubmit="confirm()">
<button id="flushdb" type="submit">Flush the database</button>
</form>
<h3 style="color: blue">TRACK VICTIMS</h3>
<p>Select a victim from the list below:- </p>
<button id="refresh">Refresh Victims</button>
<div id="selectbtndiv"></div>
<div id="details"></div>
<div id="chartContainer" style="height: 200px; width: 50%; float: right; margin:-170px 10px 600px 750px;"></div>
</body>
</html>
