<?php
    include "../db.php";
    $sql="select * from main";
    $result=mysqli_query($con,$sql);
    if($result)
    {
        $records=mysqli_num_rows($result);
        if($records > 0)
        {
            echo "<select id=\"selectbtn\">\n";
            echo "<option value=\"0\" selected>Select...</option>\n";
            while($row=mysqli_fetch_array($result))
            {
                $disp = $row['username']."@".$row['hostname'];
                echo "<option value=\"".$row['uid']."\">".$disp."</option>\n"; 
            }
            echo "</select>\n";
        }
        else
        {
            echo "<h1>Dashboard is not available as no machines are being tracked currently.</h1>";
        }
    }
?>