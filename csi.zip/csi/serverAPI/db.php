<?php
	date_default_timezone_set('Asia/Kolkata');
	$con = mysqli_connect("localhost","knoglexy_root","knogle@2017") or die("Cannot establish a connection to localhost");
	mysqli_select_db($con,"knoglexy_csi") or die("Cannot select the DB");
?>