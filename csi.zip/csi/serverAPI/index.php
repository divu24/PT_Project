<?php
    include "db.php";
    $uid="";
    if(isset($_POST['hostname']) && isset($_POST['username']) && $_POST['hostname']!='' && $_POST['username']!='')
    {
        $username=$_POST['username'];
        $hostname=$_POST['hostname'];
        $publicip=$_POST['publicip'];
        $privateip=$_POST['privateip'];
        $os=$_POST['os'];
        
        $sql="select * from main where username='".$username."' and hostname='".$hostname."'";
        $result=mysqli_query($con,$sql);
        if($result)
        {
            $records=mysqli_num_rows($result);
            if($records > 0)
            {
                $row=mysqli_fetch_array($result);
                $uid=$row['uid'];
                echo "Already tracking this machine at #".$uid." since ".$row['timestamp'];
            }
            else
            {
                $sql="insert into main(username,hostname,public_ip,private_ip,os) values('".$username."','".$hostname."','".$publicip."','".$privateip."','".$os."')";
                $result=mysqli_query($con,$sql);
                echo "Started tracking this machine successfully";
            }
        }
        
        
        if(isset($_POST['datapost']))
        {
            if($_POST['datapost']=='true')
            {
                if(isset($_POST['cpu']))
                {
                    $key = 'cpu';
                    $val = $_POST['cpu'];
                }
                else if(isset($_POST['ram']))
                {
                    $key = 'ram';
                    $val = $_POST['ram'];
                }
                else if(isset($_POST['battery']))
                {
                    $key = 'battery';
                    $val = $_POST['battery'];
                }
                elseif(isset($_POST['power_status']))
                {
                    $key = 'power_source';
                    $val = $_POST['power_status'];
                }
                else if(isset($_POST['uptime']))
                {
                    $key = 'uptime';
                    $val = $_POST['uptime'];
                }
                
                $sql="insert into data(uid,parameter,value) values(".$uid.",'".$key."','".$val."')";
                $result=mysqli_query($con,$sql);
                if($result)
                {
                    echo "\nData posted successfully";
                }
                else
                {
                    echo "\nInternal POST error encountered";
                }
                
            }
        }
    }
    else
    {
        echo "Works with HTTP POST request";
    }
    mysqli_close($con);
?>