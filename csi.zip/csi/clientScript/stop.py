import os

os.system('var=$(ps ax | grep final.py | cut -b 1-5 | head -1) && kill $var')
print('Tracking service is now STOPPED...')
