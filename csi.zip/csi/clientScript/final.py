import os
import requests
import psutil
import getpass
import socket
from apscheduler.schedulers.blocking import BlockingScheduler
import pdb
pdb.set_trace() 

def getuser(self):
	return str(getpass.getuser())

def gethost(self):
	return str(socket.gethostname())

def getpublicip(self):
	return requests.get('http://ip.42.pl/raw').text	

def getprivateip(self):
	s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
	s.connect(("8.8.8.8", 80))
	return str(s.getsockname()[0])
def getos(self):
	return str(os.name)

class para:
	username = ""
	hostname = ""
	url = ""
	
	def __init__(self, u):
		self.url = u
		self.username = getuser(self)
		self.hostname = gethost(self)
		payload = {
		'username': self.username,
		'hostname': self.hostname,
		'publicip': getpublicip(self),
		'privateip': getprivateip(self),
		'os': getos(self)
		}
		r = requests.post(self.url, data=payload)
		print(payload)
		print(r.text)
		print(r.status_code, r.reason)
		self.getcpu()
		self.getbattperc()
		self.getplug()
		self.getuptime()
		self.getram()
	
	
	# Utility functions
	def getcpu(self):
		self.post2server('cpu',str(psutil.cpu_percent(interval=1)))
 
	def getbattperc(self):
		battery = psutil.sensors_battery()
		percent = str(battery.percent)
		self.post2server('battery',percent)	
	
	def getplug(self):
		battery = psutil.sensors_battery()
		plugged = battery.power_plugged
		if plugged==False: plugged='On battery'	
		else: plugged='Plugged In'
		self.post2server('power_status',plugged) 

	def getuptime(self):
		abcd = str(os.popen('uptime | cut -b 14-18').read())
		self.post2server('uptime',abcd)
	
	def getram(self):
		abcde = psutil.virtual_memory()
		self.post2server('ram',str(abcde.percent))
	
	def post2server(self,parameter,value):
		payload = {
		'datapost': 'true',
		'username': self.username,
		'hostname': self.hostname,
		 parameter: value
		}
		r = requests.post(self.url, data=payload)
		print(payload)
		print(r.text)
		print(r.status_code, r.reason)

print('Checking for requirements in this machine')
print(os.popen('sudo pip3 install -r requirements.txt').read())
p = para('http://knogle.xyz/csi/')
scheduler = BlockingScheduler()
scheduler.add_job(p.getcpu, 'interval', seconds=5)
scheduler.add_job(p.getbattperc, 'interval', seconds=180)
scheduler.add_job(p.getplug, 'interval', seconds=60)
scheduler.add_job(p.getuptime, 'interval', seconds=900)
scheduler.add_job(p.getram, 'interval', seconds=15)
try:
	scheduler.start()
except (KeyboardInterrupt, SystemExit):
	pass
