import os

os.system('nohup python3 -u final.py > ./mylog.log  2>&1 &')
print('Tracking service is now running...')
